Prvi projekat iz predmeta NapredneBazePodataka<br />
Clanovi tima:   <br />
Slavko Petrovic <br />
Natalija Pavlovic https://github.com/natalijapavlovic17321<br />
Mateja Pancic https://github.com/matetebra<br />
Aleksandra Djokic https://github.com/aleksandradjokic<br />
