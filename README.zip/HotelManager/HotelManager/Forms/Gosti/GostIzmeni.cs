﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManager.Forms.Gosti
{
    public partial class GostIzmeni : Form
    {
        public GostIzmeni()
        {
            InitializeComponent();
        }
        //Ovde ce recepcionar da vrsi izmenu gosta, jedino sto mi ima smisla je izmena datuma boravka ukoliko hoce da produzi gostovanje
        private void GostIzmeni_Load(object sender, EventArgs e)
        {

        }
    }
}
